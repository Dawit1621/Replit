interface AIWorkspaceImageProps {
  className?: string;
}

export function AIWorkspaceImage({ className = "" }: AIWorkspaceImageProps) {
  return (
    <svg 
      viewBox="0 0 400 400" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      data-testid="ai-workspace-svg"
    >
      <defs>
        <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1e293b" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>
        <linearGradient id="screenGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1f2937" />
          <stop offset="100%" stopColor="#111827" />
        </linearGradient>
        <linearGradient id="aiGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4F46E5" />
          <stop offset="50%" stopColor="#06B6D4" />
          <stop offset="100%" stopColor="#8B5CF6" />
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
          <feMerge> 
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>

      {/* Background */}
      <rect width="400" height="400" fill="url(#bgGradient)" rx="20"/>
      
      {/* Desk surface */}
      <rect x="0" y="280" width="400" height="120" fill="#374151" rx="8"/>
      
      {/* Main monitor */}
      <rect x="120" y="100" width="160" height="100" fill="#1f2937" rx="8"/>
      <rect x="130" y="110" width="140" height="80" fill="url(#screenGradient)" rx="4"/>
      
      {/* Monitor stand */}
      <rect x="185" y="200" width="30" height="40" fill="#4b5563"/>
      <rect x="170" y="240" width="60" height="8" fill="#4b5563" rx="4"/>
      
      {/* Left monitor */}
      <rect x="40" y="120" width="120" height="75" fill="#1f2937" rx="6"/>
      <rect x="48" y="128" width="104" height="59" fill="url(#screenGradient)" rx="3"/>
      
      {/* Right monitor */}
      <rect x="240" y="120" width="120" height="75" fill="#1f2937" rx="6"/>
      <rect x="248" y="128" width="104" height="59" fill="url(#screenGradient)" rx="3"/>
      
      {/* AI Neural Network Visualization on Main Screen */}
      <g transform="translate(130, 110)">
        {/* Central node */}
        <circle cx="70" cy="40" r="8" fill="url(#aiGradient)" filter="url(#glow)"/>
        
        {/* Connected nodes */}
        <circle cx="40" cy="20" r="5" fill="url(#aiGradient)" opacity="0.8"/>
        <circle cx="100" cy="20" r="5" fill="url(#aiGradient)" opacity="0.8"/>
        <circle cx="40" cy="60" r="5" fill="url(#aiGradient)" opacity="0.8"/>
        <circle cx="100" cy="60" r="5" fill="url(#aiGradient)" opacity="0.8"/>
        <circle cx="20" cy="40" r="4" fill="url(#aiGradient)" opacity="0.6"/>
        <circle cx="120" cy="40" r="4" fill="url(#aiGradient)" opacity="0.6"/>
        
        {/* Connection lines */}
        <line x1="70" y1="40" x2="40" y2="20" stroke="url(#aiGradient)" strokeWidth="2" opacity="0.6"/>
        <line x1="70" y1="40" x2="100" y2="20" stroke="url(#aiGradient)" strokeWidth="2" opacity="0.6"/>
        <line x1="70" y1="40" x2="40" y2="60" stroke="url(#aiGradient)" strokeWidth="2" opacity="0.6"/>
        <line x1="70" y1="40" x2="100" y2="60" stroke="url(#aiGradient)" strokeWidth="2" opacity="0.6"/>
        <line x1="70" y1="40" x2="20" y2="40" stroke="url(#aiGradient)" strokeWidth="2" opacity="0.6"/>
        <line x1="70" y1="40" x2="120" y2="40" stroke="url(#aiGradient)" strokeWidth="2" opacity="0.6"/>
        
        {/* Data flow indicators */}
        <circle cx="55" cy="30" r="2" fill="#06B6D4" opacity="0.8">
          <animate attributeName="opacity" values="0.3;1;0.3" dur="2s" repeatCount="indefinite"/>
        </circle>
        <circle cx="85" cy="50" r="2" fill="#8B5CF6" opacity="0.8">
          <animate attributeName="opacity" values="0.3;1;0.3" dur="2.5s" repeatCount="indefinite"/>
        </circle>
      </g>
      
      {/* Code on left screen */}
      <g transform="translate(48, 128)">
        <rect x="5" y="5" width="94" height="3" fill="#4F46E5" opacity="0.7"/>
        <rect x="5" y="12" width="70" height="3" fill="#06B6D4" opacity="0.7"/>
        <rect x="5" y="19" width="85" height="3" fill="#8B5CF6" opacity="0.7"/>
        <rect x="5" y="26" width="60" height="3" fill="#4F46E5" opacity="0.7"/>
        <rect x="5" y="33" width="80" height="3" fill="#06B6D4" opacity="0.7"/>
        <rect x="5" y="40" width="75" height="3" fill="#8B5CF6" opacity="0.7"/>
        <rect x="5" y="47" width="65" height="3" fill="#4F46E5" opacity="0.7"/>
      </g>
      
      {/* Analytics on right screen */}
      <g transform="translate(248, 128)">
        {/* Chart bars */}
        <rect x="10" y="35" width="8" height="15" fill="#4F46E5" opacity="0.8"/>
        <rect x="25" y="25" width="8" height="25" fill="#06B6D4" opacity="0.8"/>
        <rect x="40" y="30" width="8" height="20" fill="#8B5CF6" opacity="0.8"/>
        <rect x="55" y="20" width="8" height="30" fill="#4F46E5" opacity="0.8"/>
        <rect x="70" y="28" width="8" height="22" fill="#06B6D4" opacity="0.8"/>
        
        {/* Chart lines */}
        <line x1="10" y1="52" x2="90" y2="52" stroke="#64748b" strokeWidth="1"/>
        <line x1="10" y1="52" x2="10" y2="10" stroke="#64748b" strokeWidth="1"/>
      </g>
      
      {/* Keyboard */}
      <rect x="150" y="250" width="100" height="25" fill="#374151" rx="4"/>
      <g transform="translate(155, 255)">
        {Array.from({length: 15}, (_, i) => (
          <rect key={i} x={i * 6} y="0" width="4" height="4" fill="#4b5563" rx="1"/>
        ))}
        {Array.from({length: 12}, (_, i) => (
          <rect key={i} x={3 + i * 7} y="8" width="4" height="4" fill="#4b5563" rx="1"/>
        ))}
        {Array.from({length: 10}, (_, i) => (
          <rect key={i} x={6 + i * 8} y="16" width="4" height="4" fill="#4b5563" rx="1"/>
        ))}
      </g>
      
      {/* Mouse */}
      <ellipse cx="280" cy="262" rx="12" ry="18" fill="#374151"/>
      <ellipse cx="280" cy="260" rx="10" ry="15" fill="#4b5563"/>
      
      {/* Coffee cup */}
      <rect x="320" y="240" width="25" height="30" fill="#8b4513" rx="3"/>
      <rect x="322" y="242" width="21" height="26" fill="#a0522d" rx="2"/>
      <ellipse cx="332.5" cy="242" rx="10.5" ry="3" fill="#654321"/>
      <path d="M 345 250 Q 355 250 355 260 Q 355 270 345 270" stroke="#8b4513" strokeWidth="3" fill="none"/>
      
      {/* Steam from coffee */}
      <g opacity="0.6">
        <path d="M 328 235 Q 330 225 328 215" stroke="#e5e7eb" strokeWidth="2" fill="none">
          <animate attributeName="opacity" values="0.3;0.8;0.3" dur="3s" repeatCount="indefinite"/>
        </path>
        <path d="M 332 235 Q 334 225 332 215" stroke="#e5e7eb" strokeWidth="2" fill="none">
          <animate attributeName="opacity" values="0.8;0.3;0.8" dur="3s" repeatCount="indefinite"/>
        </path>
        <path d="M 336 235 Q 338 225 336 215" stroke="#e5e7eb" strokeWidth="2" fill="none">
          <animate attributeName="opacity" values="0.3;0.8;0.3" dur="3s" repeatCount="indefinite"/>
        </path>
      </g>
      
      {/* AI Brand logos floating */}
      <g opacity="0.4">
        <text x="50" y="80" fill="url(#aiGradient)" fontSize="12" fontWeight="bold">AI</text>
        <text x="320" y="90" fill="url(#aiGradient)" fontSize="10" fontWeight="bold">ML</text>
        <text x="80" y="320" fill="url(#aiGradient)" fontSize="10" fontWeight="bold">GPT</text>
        <text x="300" y="330" fill="url(#aiGradient)" fontSize="10" fontWeight="bold">CLAUDE</text>
        <text x="20" y="350" fill="url(#aiGradient)" fontSize="8" fontWeight="bold">DEEPSEEK</text>
        <text x="250" y="50" fill="url(#aiGradient)" fontSize="8" fontWeight="bold">LLAMA</text>
      </g>
    </svg>
  );
}