import { Github, Linkedin, Twitter, Globe } from "lucide-react";

export function Footer() {
  const socialLinks = [
    { name: "GitHub", href: "#", icon: Github },
    { name: "LinkedIn", href: "#", icon: Linkedin },
    { name: "Twitter", href: "#", icon: Twitter },
    { name: "Blog", href: "#", icon: Globe },
  ];

  return (
    <footer className="bg-slate-900 dark:bg-slate-950 text-slate-300 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-bold text-white mb-4">DevAI</h3>
            <p className="text-slate-400 mb-4">
              Innovation through AI and tech - pioneering intelligent solutions for tomorrow.
            </p>
            <div className="flex justify-center md:justify-start space-x-4">
              {socialLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-slate-400 hover:text-white transition-colors"
                    data-testid={`footer-${link.name.toLowerCase()}`}
                    aria-label={link.name}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>

          <div className="text-center">
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="/" className="block text-slate-400 hover:text-white transition-colors" data-testid="footer-home">
                Home
              </a>
              <a href="/projects" className="block text-slate-400 hover:text-white transition-colors" data-testid="footer-projects">
                Projects
              </a>
              <a href="/about" className="block text-slate-400 hover:text-white transition-colors" data-testid="footer-about">
                About
              </a>
              <a href="/contact" className="block text-slate-400 hover:text-white transition-colors" data-testid="footer-contact">
                Contact
              </a>
            </div>
          </div>

          <div className="text-center md:text-right">
            <h4 className="text-lg font-semibold text-white mb-4">Contact Info</h4>
            <div className="space-y-2 text-slate-400">
              <p data-testid="footer-email">contact@devai.com</p>
              <p data-testid="footer-phone">+1 (234) 567-8900</p>
              <p data-testid="footer-location">San Francisco, CA</p>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
          <p data-testid="footer-copyright">&copy; 2024 DevAI. All rights reserved.</p>
          <p className="text-sm mt-2" data-testid="footer-built-with">Built with AI, React, Node.js, and innovation</p>
        </div>
      </div>
    </footer>
  );
}
