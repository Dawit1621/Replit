interface BrandLogoProps {
  className?: string;
}

export function BrandLogo({ className = "w-8 h-8" }: BrandLogoProps) {
  return (
    <svg 
      viewBox="0 0 32 32" 
      className={className}
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      data-testid="brand-logo"
    >
      <defs>
        <linearGradient id="brandGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4F46E5" />
          <stop offset="100%" stopColor="#06B6D4" />
        </linearGradient>
      </defs>
      
      {/* Central hub */}
      <circle cx="16" cy="16" r="3" fill="url(#brandGradient)" />
      
      {/* Top connection */}
      <circle cx="16" cy="6" r="2.5" fill="url(#brandGradient)" />
      <line x1="16" y1="13" x2="16" y2="8.5" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Bottom connection */}
      <circle cx="16" cy="26" r="2.5" fill="url(#brandGradient)" />
      <line x1="16" y1="19" x2="16" y2="23.5" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Left connection */}
      <circle cx="6" cy="16" r="2.5" fill="url(#brandGradient)" />
      <line x1="13" y1="16" x2="8.5" y2="16" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Right connection */}
      <circle cx="26" cy="16" r="2.5" fill="url(#brandGradient)" />
      <line x1="19" y1="16" x2="23.5" y2="16" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Top-left diagonal */}
      <circle cx="9.5" cy="9.5" r="2" fill="url(#brandGradient)" />
      <line x1="14.5" y1="14.5" x2="11.5" y2="11.5" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Top-right diagonal */}
      <circle cx="22.5" cy="9.5" r="2" fill="url(#brandGradient)" />
      <line x1="17.5" y1="14.5" x2="20.5" y2="11.5" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Bottom-left diagonal */}
      <circle cx="9.5" cy="22.5" r="2" fill="url(#brandGradient)" />
      <line x1="14.5" y1="17.5" x2="11.5" y2="20.5" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
      
      {/* Bottom-right diagonal */}
      <circle cx="22.5" cy="22.5" r="2" fill="url(#brandGradient)" />
      <line x1="17.5" y1="17.5" x2="20.5" y2="20.5" stroke="url(#brandGradient)" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}