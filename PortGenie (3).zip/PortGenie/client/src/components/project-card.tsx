import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";
import type { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
  index: number;
}

export function ProjectCard({ project, index }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -4 }}
      className="h-full"
    >
      <Card className="h-full bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300">
        {project.imageUrl && (
          <img
            src={project.imageUrl}
            alt={project.title}
            className="w-full h-48 object-cover"
            data-testid={`project-image-${project.id}`}
          />
        )}
        
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold mb-3 text-slate-900 dark:text-white" data-testid={`project-title-${project.id}`}>
            {project.title}
          </h3>
          <p className="text-slate-600 dark:text-slate-400 mb-4 line-clamp-3" data-testid={`project-description-${project.id}`}>
            {project.description}
          </p>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {project.techStack.map((tech, techIndex) => (
              <Badge
                key={techIndex}
                variant="secondary"
                className="text-xs"
                data-testid={`project-tech-${project.id}-${techIndex}`}
              >
                {tech}
              </Badge>
            ))}
          </div>
          
          <div className="flex gap-3">
            {project.demoUrl && (
              <a
                href={project.demoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
                data-testid={`project-demo-${project.id}`}
              >
                <ExternalLink className="mr-1 h-4 w-4" />
                Demo
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-slate-600 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300 transition-colors"
                data-testid={`project-github-${project.id}`}
              >
                <Github className="mr-1 h-4 w-4" />
                Code
              </a>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
