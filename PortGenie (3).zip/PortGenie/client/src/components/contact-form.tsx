import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertContactMessageSchema, type InsertContactMessage } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Send, Mail, Phone, MapPin } from "lucide-react";

export function ContactForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertContactMessage>({
    resolver: zodResolver(insertContactMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (data: InsertContactMessage) => {
      return await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Message sent!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/contact"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContactMessage) => {
    submitMutation.mutate(data);
  };

  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "contact@devai.com",
      href: "mailto:contact@devai.com",
    },
    {
      icon: Phone,
      label: "Phone",
      value: "(+251) 0991744263",
      href: "tel:+2510991744263",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Addis Ababa, ETHIOPIA",
      href: null,
    },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
      {/* Contact Form */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card className="bg-slate-50 dark:bg-slate-800 shadow-lg">
          <CardContent className="p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-700 dark:text-slate-300">Full Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="John Doe"
                          className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"
                          data-testid="contact-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-700 dark:text-slate-300">Email Address</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="john@example.com"
                          className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600"
                          data-testid="contact-email"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-slate-700 dark:text-slate-300">Message</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell me about your project..."
                          rows={5}
                          className="bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 resize-none"
                          data-testid="contact-message"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  size="lg"
                  disabled={submitMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
                  data-testid="contact-submit"
                >
                  <Send className="mr-2 h-4 w-4" />
                  {submitMutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </motion.div>

      {/* Contact Information */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="space-y-8"
      >
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-slate-800 dark:to-slate-700">
          <CardContent className="p-8">
            <h3 className="text-2xl font-semibold mb-6 text-slate-900 dark:text-white" data-testid="contact-info-title">
              Let's Connect
            </h3>
            
            <div className="space-y-4">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                const content = (
                  <div className="flex items-center space-x-4" data-testid={`contact-info-${index}`}>
                    <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900 dark:text-white">{info.label}</p>
                      <p className="text-blue-600 dark:text-blue-400">{info.value}</p>
                    </div>
                  </div>
                );

                return (
                  <div key={index}>
                    {info.href ? (
                      <a href={info.href} className="hover:opacity-80 transition-opacity">
                        {content}
                      </a>
                    ) : (
                      content
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Social Links */}
        <div className="text-center">
          <h4 className="text-lg font-medium mb-4 text-slate-900 dark:text-white" data-testid="social-title">
            Follow Me
          </h4>
          <div className="flex justify-center space-x-4">
            {[
              { name: "GitHub", href: "#", color: "bg-slate-700 hover:bg-slate-600" },
              { name: "LinkedIn", href: "#", color: "bg-blue-600 hover:bg-blue-500" },
              { name: "Twitter", href: "#", color: "bg-sky-500 hover:bg-sky-400" },
              { name: "Blog", href: "#", color: "bg-gray-600 hover:bg-gray-500" },
            ].map((social, index) => (
              <a
                key={social.name}
                href={social.href}
                className={`w-12 h-12 ${social.color} text-white rounded-full flex items-center justify-center transition-colors`}
                data-testid={`social-${social.name.toLowerCase()}`}
                aria-label={social.name}
              >
                <span className="text-sm font-medium">{social.name[0]}</span>
              </a>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
