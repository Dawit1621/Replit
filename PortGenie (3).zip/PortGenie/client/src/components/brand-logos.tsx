import { motion } from "framer-motion";
import { SiOpenai, SiMeta, SiAnthropic } from "react-icons/si";
import { Brain, Code2, Zap } from "lucide-react";

const brands = [
  {
    name: "OpenAI",
    icon: SiOpenai,
    color: "text-green-600 dark:text-green-400"
  },
  {
    name: "DeepSeek",
    icon: Brain,
    color: "text-blue-600 dark:text-blue-400"
  },
  {
    name: "LLaMA",
    icon: SiMeta,
    color: "text-blue-500 dark:text-blue-300"
  },
  {
    name: "Claude",
    icon: SiAnthropic,
    color: "text-orange-600 dark:text-orange-400"
  },
  {
    name: "Prompt Engineering",
    icon: Code2,
    color: "text-purple-600 dark:text-purple-400"
  },
  {
    name: "AI Engineering",
    icon: Zap,
    color: "text-yellow-600 dark:text-yellow-400"
  }
];

export function BrandLogos() {
  return (
    <motion.div
      className="mt-12 mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 1.0 }}
    >
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 text-center font-medium">
        Powered by cutting-edge AI technologies
      </p>
      <div className="flex flex-wrap justify-center items-center gap-8 max-w-4xl mx-auto">
        {brands.map((brand, index) => {
          const IconComponent = brand.icon;
          return (
            <motion.div
              key={brand.name}
              className="group cursor-pointer"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ 
                duration: 0.4, 
                delay: 1.2 + index * 0.1,
                type: "spring",
                stiffness: 100 
              }}
              whileHover={{ 
                scale: 1.1,
                transition: { duration: 0.2 }
              }}
              data-testid={`brand-${brand.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flex flex-col items-center space-y-2 p-3 rounded-lg transition-all duration-300 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <IconComponent 
                  className={`h-8 w-8 ${brand.color} transition-all duration-300 group-hover:scale-110`} 
                />
                <span className="text-xs font-medium text-slate-600 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200 transition-colors duration-300">
                  {brand.name}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}