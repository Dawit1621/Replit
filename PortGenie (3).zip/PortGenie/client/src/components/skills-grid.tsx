import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const skills = [
  { name: "Machine Learning", icon: "🤖" },
  { name: "Python", icon: "🐍" },
  { name: "TensorFlow", icon: "🧠" },
  { name: "Natural Language Processing", icon: "💬" },
  { name: "Computer Vision", icon: "👁️" },
  { name: "Deep Learning", icon: "🔬" },
];

export function SkillsGrid() {
  return (
    <div className="mb-8">
      <h3 className="text-xl font-semibold mb-4 text-slate-900 dark:text-white" data-testid="skills-title">
        Technical Skills
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {skills.map((skill, index) => (
          <motion.div
            key={skill.name}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="bg-white dark:bg-slate-700 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="flex items-center space-x-3 p-3">
                <span className="text-2xl" data-testid={`skill-icon-${index}`}>{skill.icon}</span>
                <span className="text-slate-700 dark:text-slate-300 font-medium" data-testid={`skill-name-${index}`}>
                  {skill.name}
                </span>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
