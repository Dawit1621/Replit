import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { SkillsGrid } from "@/components/skills-grid";
import { Download } from "lucide-react";
import { AIWorkspaceImage } from "@/components/ai-workspace-image";

export default function About() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-800 py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* About Content */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-slate-900 dark:text-white" data-testid="about-title">
              About DevAI
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-6 leading-relaxed" data-testid="about-bio-1">
              DevAI is at the forefront of artificial intelligence innovation, specializing in creating intelligent solutions 
              that bridge the gap between complex AI technologies and practical business applications.
            </p>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 leading-relaxed" data-testid="about-bio-2">
              Our mission is to democratize AI technology, making advanced machine learning and intelligent automation 
              accessible to businesses of all sizes while pushing the boundaries of what's possible.
            </p>

            <SkillsGrid />

            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
              data-testid="download-resume"
            >
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </Button>
          </motion.div>

          {/* Profile Image */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center lg:text-right"
          >
            <AIWorkspaceImage className="rounded-2xl shadow-2xl w-full max-w-lg mx-auto" />
          </motion.div>
        </div>
      </div>
    </div>
  );
}
